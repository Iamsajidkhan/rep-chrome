chrome.devtools.panels.create(
    "Rep+",
    "icons/icon16.png",
    "panel.html",
    function (panel) {
        console.log("Repeater panel created");
    }
);
